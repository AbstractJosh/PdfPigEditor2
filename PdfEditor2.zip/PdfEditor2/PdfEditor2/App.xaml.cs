﻿using System.Windows;

namespace PdfStudio
{
    public partial class App : Application { }
}


﻿using Microsoft.Win32;
using PdfiumViewer;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Forms.Integration;
using System.Windows.Input;

namespace PdfStudio
{
    public partial class MainWindow : Window
    {
        private WindowsFormsHost _host;
        private PdfViewer _viewer;              // WinForms control from PdfiumViewer
        private PdfDocument _pdfiumDoc;         // PdfiumViewer.PdfDocument (be careful: name clashes with PDFsharp.Pdf.PdfDocument)
        private string? _currentPath;

        public MainWindow()
        {
            InitializeComponent();

            _host = WinFormsHost;
            _viewer = new PdfViewer
            {
                Dock = System.Windows.Forms.DockStyle.Fill,
                ShowToolbar = false,
                ShowScrollbar = true
            };
            _host.Child = _viewer;

            // Default zoom dropdown
            ZoomBox.SelectedIndex = 2; // 100%
        }

        #region UI wiring

        private void OpenPdf_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf",
                Title = "Open PDF"
            };
            if (dlg.ShowDialog() == true)
            {
                LoadIntoViewer(dlg.FileName);
                StatusText.Text = $"Opened: {dlg.FileName}";
            }
        }

        private void CreateNewPdf_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Create a very simple PDF using PDFsharp + MigraDoc (here we use PDFsharp drawing)
                var tempPath = Path.Combine(Path.GetTempPath(), $"PDFStudio_{Guid.NewGuid():N}.pdf");
                CreateSamplePdf(tempPath);
                LoadIntoViewer(tempPath);
                StatusText.Text = "Created new PDF and loaded it.";
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Create PDF error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveAs_Click(object sender, RoutedEventArgs e)
        {
            if (_pdfiumDoc == null) return;

            var dlg = new SaveFileDialog
            {
                Filter = "PDF files (*.pdf)|*.pdf",
                Title = "Save PDF As"
            };
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    // PdfiumViewer can save the underlying bytes we loaded.
                    // If we opened from a path, we can copy; if we opened from stream, we cached bytes.
                    if (!string.IsNullOrEmpty(_currentPath) && File.Exists(_currentPath))
                    {
                        File.Copy(_currentPath, dlg.FileName, overwrite: true);
                    }
                    else
                    {
                        // If loaded from memory, re-export from Pdfium (renders pages to images, not ideal)
                        // Better approach: cache original byte[] when loading.
                        if (_pdfBytesCache != null)
                        {
                            File.WriteAllBytes(dlg.FileName, _pdfBytesCache);
                        }
                        else
                        {
                            MessageBox.Show(this, "No original PDF bytes to save.", "Save As", MessageBoxButton.OK, MessageBoxImage.Information);
                            return;
                        }
                    }
                    StatusText.Text = $"Saved: {dlg.FileName}";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, ex.Message, "Save As error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e)
        {
            if (_viewer.Document == null) return;
            var p = Math.Max(1, _viewer.Page - 1);
            _viewer.Page = p;
            PageBox.Text = p.ToString();
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            if (_viewer.Document == null) return;
            var p = Math.Min(_viewer.Document.PageCount, _viewer.Page + 1);
            _viewer.Page = p;
            PageBox.Text = p.ToString();
        }

        private void PageBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter && _viewer.Document != null)
            {
                if (int.TryParse(PageBox.Text, out var p))
                {
                    p = Math.Clamp(p, 1, _viewer.Document.PageCount);
                    _viewer.Page = p;
                    PageBox.Text = p.ToString();
                }
            }
        }

        private void ZoomBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (_viewer.Document == null || ZoomBox.SelectedItem == null) return;
            var text = (ZoomBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString();
            if (text != null && text.EndsWith("%") && int.TryParse(text.TrimEnd('%'), out var percent))
            {
                _viewer.ZoomMode = PdfViewerZoomMode.Fixed;
                _viewer.Zoom = percent / 100.0;
            }
        }

        #endregion

        #region Loading & creating

        private byte[]? _pdfBytesCache;

        private void LoadIntoViewer(string path)
        {
            DisposeCurrent();

            _currentPath = path;
            _pdfBytesCache = File.ReadAllBytes(path);

            _pdfiumDoc = PdfiumViewer.PdfDocument.Load(new MemoryStream(_pdfBytesCache, writable: false));
            _viewer.Document = _pdfiumDoc;

            EnableViewerUi(true);
            PageBox.Text = "1";
            PageCountText.Text = $"/ {_viewer.Document.PageCount}";
            _viewer.Page = 1;
            _viewer.ZoomMode = PdfViewerZoomMode.FitWidth; // initial fit
        }

        private void EnableViewerUi(bool on)
        {
            SaveAsButton.IsEnabled = on;
            PrevBtn.IsEnabled = on;
            NextBtn.IsEnabled = on;
            PageBox.IsEnabled = on;
            ZoomBox.IsEnabled = on;
        }

        private void DisposeCurrent()
        {
            if (_viewer != null)
            {
                _viewer.Document = null;
            }
            if (_pdfiumDoc != null)
            {
                _pdfiumDoc.Dispose();
                _pdfiumDoc = null!;
            }
            _currentPath = null;
            _pdfBytesCache = null;
            EnableViewerUi(false);
            PageBox.Text = "";
            PageCountText.Text = "/ 0";
        }

        private static void CreateSamplePdf(string outputPath)
        {
            // Minimal sample with PDFsharp: one page, a heading string
            var doc = new PdfSharp.Pdf.PdfDocument();
            doc.Info.Title = "New PDF from PDFsharp";

            var page = doc.AddPage();
            using (var gfx = XGraphics.FromPdfPage(page))
            {
                var font = new XFont("Arial", 20, XFontStyle.Bold);
                gfx.DrawString("Hello from PDFsharp + .NET 6", font, XBrushes.Black, new XPoint(60, 100));

                var small = new XFont("Arial", 12, XFontStyle.Regular);
                gfx.DrawString("You created this PDF from the app and it opened here automatically.",
                               small, XBrushes.Black, new XPoint(60, 140));
            }

            doc.Save(outputPath);
            doc.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            DisposeCurrent();
            base.OnClosed(e);
        }

        #endregion
    }
}

﻿using System.Windows;

namespace PdfStudio
{
    // Disambiguate the base type explicitly:
    public partial class App : System.Windows.Application
    {
        // no code needed
    }
}



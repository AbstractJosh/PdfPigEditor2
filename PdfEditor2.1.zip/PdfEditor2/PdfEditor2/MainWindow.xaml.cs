﻿// ===== Aliases to avoid name collisions =====
using WinOpenFileDialog = Microsoft.Win32.OpenFileDialog;
using WinSaveFileDialog = Microsoft.Win32.SaveFileDialog;
using WpfMessageBox = System.Windows.MessageBox;

using WF = System.Windows.Forms;                    // WinForms root
using WFI = System.Windows.Forms.Integration;       // WindowsFormsHost

using PdfiumDocument = PdfiumViewer.PdfDocument;  // Pdfium doc
using PdfSharpDocument = PdfSharp.Pdf.PdfDocument;  // PDFsharp doc
using WinKeyEventArgs = System.Windows.Input.KeyEventArgs;
using WFKeyEventArgs = System.Windows.Forms.KeyEventArgs;

// ===== Normal usings =====
using PdfiumViewer;
using PdfSharp.Drawing;
using System;
using System.IO;
using System.Windows;
using System.Windows.Input;

namespace PdfStudio
{
    public partial class MainWindow : Window
    {
        private PdfRenderer _renderer;                // instead of PdfViewer
        private PdfViewer _viewer;                 // WinForms control
        private PdfiumDocument? _pdfiumDoc;        // Pdfium doc (aliased)
        private byte[]? _pdfBytesCache;
        private string? _currentPath;

        public MainWindow()
        {
            InitializeComponent();

            // Create and host the WinForms PdfViewer inside the XAML WindowsFormsHost named "WinFormsHost"
            _viewer = new PdfViewer
            {
                Dock = WF.DockStyle.Fill,
                ShowToolbar = false
                // NOTE: Some versions don't expose ShowScrollbars — omit it to be safe
            };
            WinFormsHost.Child = _viewer;

            ZoomBox.SelectedIndex = 2; // "100%"
        }

        // ---------------- UI Handlers ----------------

        private void OpenPdf_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new WinOpenFileDialog { Filter = "PDF files (*.pdf)|*.pdf", Title = "Open PDF" };
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    LoadIntoViewer(dlg.FileName);
                    StatusText.Text = $"Opened: {dlg.FileName}";
                }
                catch (Exception ex)
                {
                    WpfMessageBox.Show(this, ex.ToString(), "Load error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void CreateNewPdf_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var tempPath = Path.Combine(Path.GetTempPath(), $"PDFStudio_{Guid.NewGuid():N}.pdf");
                CreateSamplePdf(tempPath);
                LoadIntoViewer(tempPath);
                StatusText.Text = "Created new PDF and loaded it.";
            }
            catch (Exception ex)
            {
                WpfMessageBox.Show(this, ex.Message, "Create PDF error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SaveAs_Click(object sender, RoutedEventArgs e)
        {
            if (_pdfiumDoc == null) return;

            var dlg = new WinSaveFileDialog { Filter = "PDF files (*.pdf)|*.pdf", Title = "Save PDF As" };
            if (dlg.ShowDialog() == true)
            {
                try
                {
                    if (!string.IsNullOrEmpty(_currentPath) && File.Exists(_currentPath))
                    {
                        File.Copy(_currentPath, dlg.FileName, overwrite: true);
                    }
                    else if (_pdfBytesCache != null)
                    {
                        File.WriteAllBytes(dlg.FileName, _pdfBytesCache);
                    }
                    else
                    {
                        WpfMessageBox.Show(this, "No original PDF bytes to save.", "Save As",
                                           MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                    StatusText.Text = $"Saved: {dlg.FileName}";
                }
                catch (Exception ex)
                {
                    WpfMessageBox.Show(this, ex.Message, "Save As error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void PrevPage_Click(object sender, RoutedEventArgs e)
        {
            if (_viewer.Document == null) return;
            var p = Math.Max(1, _viewer.Renderer.Page - 1);   // Renderer API
            _viewer.Renderer.Page = p;
            PageBox.Text = p.ToString();
        }

        private void NextPage_Click(object sender, RoutedEventArgs e)
        {
            if (_viewer.Document == null) return;
            var p = Math.Min(_viewer.Document.PageCount, _viewer.Renderer.Page + 1);
            _viewer.Renderer.Page = p;
            PageBox.Text = p.ToString();
        }

        private void PageBox_KeyDown(object sender, WinKeyEventArgs e)
        {
            if (e.Key == Key.Enter && _viewer.Document != null)
            {
                if (int.TryParse(PageBox.Text, out var p))
                {
                    p = Math.Clamp(p, 1, _viewer.Document.PageCount);
                    _viewer.Renderer.Page = p;
                    PageBox.Text = p.ToString();
                }
            }
        }

        private void ZoomBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (_viewer.Document == null || ZoomBox.SelectedItem == null) return;

            var text = (ZoomBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content?.ToString();
            if (text != null && text.EndsWith("%") && int.TryParse(text.TrimEnd('%'), out var percent))
            {
                // Do NOT set ZoomMode here (since your enum lacks None/Fixed).
                _viewer.Renderer.Zoom = percent / 100.0;
            }
        }

        // ---------------- Load / Create ----------------

        private void LoadIntoViewer(string path)
        {
            DisposeCurrent();

            _currentPath = path;
            _pdfBytesCache = File.ReadAllBytes(path);

            _pdfiumDoc = PdfiumDocument.Load(new MemoryStream(_pdfBytesCache, writable: false));

            try
            {
                // Try rendering a tiny thumbnail of page 1; will throw if pdfium.dll isn't loading
                using var bmp = _pdfiumDoc.Render(0, 200, 260, 96, 96, true); // pageIndex=0
                var thumbPath = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "pdfstudio_probe.png");
                bmp.Save(thumbPath);
                // Optional: show where it saved so you can open it
                StatusText.Text = $"probe rendered → {thumbPath}";
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show(this, "pdfium render failed: " + ex, "Pdfium", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            _viewer.Document = _pdfiumDoc;

            EnableViewerUi(true);
            PageBox.Text = "1";
            PageCountText.Text = $"/ {_viewer.Document.PageCount}";
            _viewer.Renderer.Page = 1;
            _viewer.Renderer.ZoomMode = PdfViewerZoomMode.FitWidth; // good default
        }

        private void EnableViewerUi(bool on)
        {
            SaveAsButton.IsEnabled = on;
            PrevBtn.IsEnabled = on;
            NextBtn.IsEnabled = on;
            PageBox.IsEnabled = on;
            ZoomBox.IsEnabled = on;
        }

        private void DisposeCurrent()
        {
            if (_viewer != null) _viewer.Document = null;
            _pdfiumDoc?.Dispose();
            _pdfiumDoc = null;
            _currentPath = null;
            _pdfBytesCache = null;

            EnableViewerUi(false);
            PageBox.Text = "";
            PageCountText.Text = "/ 0";
        }

        private static void CreateSamplePdf(string outputPath)
        {
            // Minimal one-page PDF using PDFsharp
            var doc = new PdfSharpDocument();
            doc.Info.Title = "New PDF from PDFsharp";

            var page = doc.AddPage();
            using (var gfx = XGraphics.FromPdfPage(page))
            {
                var font = new XFont("Arial", 20, XFontStyleEx.Bold);
                gfx.DrawString("Hello from PDFsharp + .NET 6", font, XBrushes.Black, new XPoint(60, 100));

                var small = new XFont("Arial", 12, XFontStyleEx.Regular);
                gfx.DrawString("You created this PDF and opened it here automatically.",
                               small, XBrushes.Black, new XPoint(60, 140));
            }

            doc.Save(outputPath);
            doc.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            DisposeCurrent();
            base.OnClosed(e);
        }
    }
}